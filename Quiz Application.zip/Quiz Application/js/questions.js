


let questions = [{
  numb: 1,
  question: " In which movie would you hear the song 'Hakuna Matata'??",
  answer: "Lion King", options: [
    "Lion King",
    "Cinderella",
   "Beauty and the Beast",
    "Hercules"
  ]
},
{
  numb: 2,
  question: " In which television show would you find characters named Fred, Doris, and Arnold?",
  answer: "Green Acres",
  options: [
    "All in the Family",
    "Petticoat Junction",
    "Green Acres",
    " Beverly Hillbillies"
  ]
},
{
  numb: 3,
  question: "Which comic strip was written by Charles Schulz?",
  answer: "Peanuts",
  options: [
    "Peanuts",
    "Blondie",
    "Garfield",
    "Beetle Bailey"
  ]
},
{
  numb: 4,
  question: "Which type of scientist studies and forecasts the weather?",
  answer: "Meteorologist",
  options: [
    "Astronomer",
    "Biologist",
    "Astrologist",
    "Meteorologist"
  ]
},
{
  numb: 5,
  question: "What color would you get if you mixed red and yellow together?",
  answer: "Orange",
  options: [
    "Pink",
    "Orange",
    "Gray",
    "Deeper shade of yellow"
  ]
},
{
  numb: 6,
  question: "There are movies based on the Harry Potter series",
  answer: "yes",
  options: [
    "yes",
    "no"
  ]
},
{
  numb: 7,
  question: "Which memorable historical event took place November 22, 1963?",
  answer: "JFK's assassination",
  options: [
    "The Great Depression began",
    "The start of World War 1",
    "The bombing of Hiroshima",
    "JFK's assassination"
  ]
},
{
  numb: 8,
  question: "Which American fast food franchise serves Reese's Peanut Butter Cup Blizzards?",
  answer: "Dairy Queen",
  options: [
    "McDonald's",
    "Baskin Robbins",
    "Dairy Queen",
    "Wendy's"
  ]
},
{
  numb: 9,
  question: "What is the name of the dog in Garfield?",
  answer: "Odie",
  options: [
    "Oliver",
    "Odie",
    "Fred",
    "Tyson"
  ]
},
{
  numb: 10,
  question: "Dubble Bubble bubble gum now makes sugar free gum.",
  answer: "True",
  options: [
    "True",
    "False"
  ]
}
];
